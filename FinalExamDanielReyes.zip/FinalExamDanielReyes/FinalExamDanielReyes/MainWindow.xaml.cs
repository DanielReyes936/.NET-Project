﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Xml.Linq;

namespace FinalExamDanielReyes
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        //Charge ComboBox and Show Category
        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            using (var context = new northwindEntities())
            {
                var categories = context.Categories.ToList();

                cmbCategory.ItemsSource = categories;
                cmbCategory.DisplayMemberPath = "CategoryName";
                cmbCategory.SelectedValuePath = "CategoryID";
            }
        }

        //Load data in the grid according to the category selection
        private void GetDataFromDB()
        {
            if (cmbCategory.SelectedItem != null)
            {
                int id = Convert.ToInt32(cmbCategory.SelectedValue);
                using (var context = new northwindEntities())
                {
                    var products = (from s in context.Products
                                    where s.CategoryID == id
                                    select s).ToList(); ;

                    FillDataGrid(products);
                }
            }
            else
                using (var context = new northwindEntities())
            { var products = context.Products.ToList();
               
                FillDataGrid(products);
            }
            
        }

        //Select columns to display
        private void FillDataGrid(List<Product> products)
        {
            grdproducts.ItemsSource = products;
            grdproducts.Columns[2].Visibility = Visibility.Collapsed;
            grdproducts.Columns[7].Visibility = Visibility.Collapsed;
            grdproducts.Columns[8].Visibility = Visibility.Collapsed;
            grdproducts.Columns[9].Visibility = Visibility.Collapsed;
            grdproducts.Columns[10].Visibility = Visibility.Collapsed;
            grdproducts.Columns[11].Visibility = Visibility.Collapsed;
            grdproducts.Columns[12].Visibility = Visibility.Collapsed;
          
        }
        
        //Open SecondPage
        private void AddNewProduct(object sender, RoutedEventArgs e)
        {
            SecondPage win2 = new SecondPage();
            win2.Show();
        }

        //button to load data in the grid
        private void Button_GetAllProducts(object sender, RoutedEventArgs e)
        {
            GetDataFromDB();

        }

        //// Button to delete data 
        private void Button_ClearData(object sender, RoutedEventArgs e)
        {
            grdproducts.ItemsSource = "" ;
            txtName.Text = "";
            cmbCategory.SelectedIndex = -1;
        }

        //Search a product
        private void Button_Search(object sender, RoutedEventArgs e)
        {
            try
            {
                using (var context = new northwindEntities())
                {
                    // query syntax
                    var students = (from std in context.Products
                                    where std.ProductName.Contains(txtName.Text)
                                    select std).ToList();

                   FillDataGrid(students);
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }

        }

        
    }
}
