﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Xml.Linq;

namespace FinalExamDanielReyes
{
    /// <summary>
    /// Interaction logic for SecondPage.xaml
    /// </summary>
    public partial class SecondPage : Window
    {
        public SecondPage()
        {
            InitializeComponent();
        }

        //Charge ComboBox and Show Category
        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            using (var context = new northwindEntities())
            {
                var categories = context.Categories.ToList();

                cmbCategory.ItemsSource = categories;
                cmbCategory.DisplayMemberPath = "CategoryName";
                cmbCategory.SelectedValuePath = "CategoryID";
            }
        }

        //Close SecondPage
        private void Button_Close(object sender, RoutedEventArgs e)
        {
            Close();
        }

        //Add new Product in DB
        private void Button_AddProduct(object sender, RoutedEventArgs e)
        {
            using (var context = new northwindEntities())
            {
                
                Product std = new Product();
                std.ProductName = txtName.Text;
                std.UnitPrice = Convert.ToInt32(txtPrice.Text);
                std.CategoryID = Convert.ToInt32(cmbCategory.SelectedValue); //Category difine in combobox
                                
                context.Products.Add(std);                
                context.SaveChanges(); // Save Changes to Database.
                        
                
                MessageBox.Show("New Product Added", "Success", MessageBoxButton.OK, MessageBoxImage.Information);
            }
        }

      
    }
}
